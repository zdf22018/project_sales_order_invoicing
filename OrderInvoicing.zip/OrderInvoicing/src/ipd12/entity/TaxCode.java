
package ipd12.entity;

/**
 *
 * @author zhao
 */
public enum TaxCode {
    gst, 
    qst, 
    gstqst, 
    nosalestax
}
